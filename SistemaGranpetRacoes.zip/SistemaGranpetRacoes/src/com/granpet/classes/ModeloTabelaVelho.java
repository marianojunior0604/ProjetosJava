/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.granpet.classes;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Junior
 */
public class ModeloTabelaVelho extends AbstractTableModel {
    
    private List<Cliente> clientes;
    private String[] colunas;
    private int ncolunas;

    public ModeloTabelaVelho() {
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    public String[] getColunas() {
        return colunas;
    }

    public void setColunas(String[] colunas) {
        this.colunas = colunas;
    }

    public int getNcolunas() {
        return ncolunas;
    }

    public void setNcolunas(int ncolunas) {
        this.ncolunas = ncolunas;
    }

    @Override
    public int getRowCount() {
        return clientes.size();
    }

    @Override
    public int getColumnCount() {
        return ncolunas;
    }

    @Override
    public Object getValueAt(int i, int i1) {
        Cliente c = clientes.get(i);
        return c;
    }
    
    public void adicionar(Cliente c){
        clientes.add(c);
        fireTableRowsInserted(clientes.size() - 1, clientes.size() - 1);
    }
    
}
