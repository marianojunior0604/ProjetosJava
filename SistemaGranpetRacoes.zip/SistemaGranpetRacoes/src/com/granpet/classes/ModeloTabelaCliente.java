/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.granpet.classes;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Junior
 */
public class ModeloTabelaCliente extends AbstractTableModel{
    
    private String[] nomeColunas;
    private ArrayList<Cliente> linhas;
    private int numeroColunas;

    public ModeloTabelaCliente() {
    }

    public String[] getNomeColunas() {
        return nomeColunas;
    }

    public void setNomeColunas(String[] nomeColunas) {
        this.nomeColunas = nomeColunas;
    }

    public List<Cliente> getLinhas() {
        return linhas;
    }

    public void setLinhas(ArrayList<Cliente> linhas) {
        this.linhas = linhas;
    }

    public int getNumeroColunas() {
        return numeroColunas;
    }

    public void setNumeroColunas(int numeroColunas) {
        this.numeroColunas = numeroColunas;
    }
    
    @Override
    public int getRowCount() {
        if(null == linhas){
            return 0;
        }
        return linhas.size();
    }

    @Override
    public int getColumnCount() {
        return numeroColunas;
    }

    @Override
    public Object getValueAt(int linha, int coluna) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
