/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.drogaria.pessoa.funcoes;

import com.drogaria.pessoa.DAL.ModuloConector;
import com.drogaria.pessoa.beans.Usuario;
import com.drogaria.pessoa.classes.Hash;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Junior
 */
public class FuncoesUsuario {

    Usuario usuario = new Usuario();
    Connection conexao = ModuloConector.conector();
    PreparedStatement pst = null;
    ResultSet rs = null;

    public Usuario logarSistema(String login, String senha) {
        String sql = "SELECT * FROM `dbo.usuarios` WHERE `loginUsuario` = ? AND `senhaUsuario` = ?";
        senha = Hash.toHexadecimal(senha.getBytes());
        String pass = "";
        try {
            pass = Hash.toMD5Hash(senha);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(FuncoesUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        //System.out.println(login + " " + pass);
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, login);
            pst.setString(2, pass);
            rs = pst.executeQuery();
            if (rs.next()) {
                usuario.setIdUsuario(rs.getInt("idUsuario"));
                usuario.setNomeUsuario(rs.getString("nomeUsuario"));
                //logou = true;
                return usuario;
            } else {
                return usuario;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao acessar o banco de dados: " + e, "Alerta", 0);
            return usuario;
        }
    }

    public boolean cadastrarUsuario(Usuario user) {
        String sql = "INSERT INTO `dbo.usuarios` (`nomeUsuario`, `loginUsuario`, `senhaUsuario`) VALUES (?, ?, ?)";
        System.out.println(user.getNomeUsuario() + " " + user.getLoginUsuario() + " " + user.getSenhaUsuario());
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, user.getNomeUsuario());
            pst.setString(2, user.getLoginUsuario());
            pst.setString(3, user.getSenhaUsuario());
            if (pst.execute()) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao acessar o banco de dados, erro: " + ex, "Alerta", 0);
            return false;
        }
    }

    public Usuario pesquisaUsuario(String nome) {
        String sql = "SELECT * FROM `dbo.usuarios` WHERE `nomeUsuario` = ?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, nome);
            rs = pst.executeQuery();
            if (rs.next()) {
                pst.setString(1, usuario.getNomeUsuario());
                pst.setString(2, usuario.getLoginUsuario());
                pst.setString(3, usuario.getSenhaUsuario());
                return usuario;
            } else {
                JOptionPane.showMessageDialog(null, "Usuario não Encontrado", "Aviso", 0);
                return null;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao acessar o banco de dados, erro: " + ex, "Alerta", 0);
            return null;
        }
    }

    public boolean excluiUsuaraio(int idUsuario) {
        String sql = "DELETE FROM `dbo.usuarios` WHERE `idUsuario` = ?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setInt(1, idUsuario);
            if (pst.execute()) {
                JOptionPane.showMessageDialog(null, "Usuario Excluido com sucesso", "Aviso", 0);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao acessar o banco de dados, erro: " + ex, "Alerta", 0);
            return false;
        }
        return true;
    }

    public boolean atualizaUsuario(Usuario user) {
        String sql = "UPDATE `dbo.usuarios` SET ` `nomeUsuario` = ?, `loginUsuario` = ?, `senhaUsuario` = ? WHERE idUsuario` = ?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, user.getNomeUsuario());
            pst.setString(2, user.getLoginUsuario());
            pst.setString(3, user.getSenhaUsuario());
            pst.setInt(4, user.getIdUsuario());
            int atualizou = pst.executeUpdate();
            if (atualizou == 1) {
                JOptionPane.showMessageDialog(null, "Usuario Atualizado com sucesso", "Aviso", 0);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao acessar o banco de dados, erro: " + ex, "Alerta", 0);
            return false;
        }
        return true;
    }

}
