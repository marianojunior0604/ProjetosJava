/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.drogaria.pessoa.funcoes;

import com.drogaria.pessoa.DAL.ModuloConector;
import com.drogaria.pessoa.beans.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Junior
 */
public class FuncoesCliente {
    
    Connection conexao = ModuloConector.conector();
    PreparedStatement pst = null;
    ResultSet rs = null;
    Cliente cliente = new Cliente();
    ArrayList<Cliente> clientes = new ArrayList();
    
    public boolean cadastraCliente(Cliente clie){
        String sql = "INSERT INTO `dbo.cli_for`(`Nome`, `Fantasia`, `Endereco`, `Bairro`, `Cidade`, `Estado`, `Inscricao`, `Fone_1`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, clie.getNomeCliente());
            pst.setString(2, clie.getNoFaClinete());
            pst.setString(3, clie.getEndeCliente());
            pst.setString(4, clie.getBairCliente());
            pst.setString(5, clie.getCidaCliente());
            pst.setString(6, clie.getEstaCliente());
            pst.setString(7, clie.getDocuCliente());
            pst.setString(8, clie.getFoneCliente());
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro, Erro ao acessar o bando de dados: " + ex, "Alerta", 0);
            return false;
        }
        return true;
    }
    
    public Cliente pesquisaCliente(String nomeCliente){
        String sql = "SELECT * FROM `dbo.cli_for` WHERE `Nome` = ?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, nomeCliente);
            rs = pst.executeQuery();
            if (rs.next()) {
                cliente.setIdCliente(rs.getInt(1));
                cliente.setNomeCliente(rs.getString(2));
                cliente.setNoFaClinete(rs.getString(3));
                cliente.setEndeCliente(rs.getString(4));
                cliente.setBairCliente(rs.getString(5));
                cliente.setCidaCliente(rs.getString(6));
                cliente.setEstaCliente(rs.getString(7));
                cliente.setDocuCliente(rs.getString(9));
                cliente.setFoneCliente(rs.getString(10));
            }else{
                //JOptionPane.showMessageDialog(null, "Clinete não encontrado", "Aviso", 0);
                return null;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro, Erro ao acessar o bando de dados: " + ex, "Alerta", 0);
            return null;
        }
        return cliente;
    }
    
    public boolean excluirCliente(int idCliente){
        String sql = "DELETE FROM `dbo.cli_for` WHERE `Codigo` = ?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setInt(1, idCliente);
            if (pst.execute()) {
                return true;
            }else{
                return false;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro, Erro ao acessar o bando de dados: " + ex, "Alerta", 0);
            return false;
        }
    }
    
    public void atualizarCliente(Cliente clie){
        String sql = "UPDATE `dbo.cli_for` SET `Nome` = ?,`Fantasia` = ?,`Endereco` = ?, `Bairro` = ?, `Cidade` = ?, `Estado` = ?, `Inscricao` = ?, `Fone_1` = ?, `Data_Alteracao` = ? WHERE `Codigo` = ?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, clie.getNomeCliente());
            pst.setString(2, clie.getNoFaClinete());
            pst.setString(3, clie.getEndeCliente());
            pst.setString(4, clie.getBairCliente());
            pst.setString(5, clie.getCidaCliente());
            pst.setString(6, clie.getEstaCliente());
            pst.setString(7, clie.getDocuCliente());
            pst.setString(8, clie.getFoneCliente());
            pst.setString(9, clie.getDaAlCliente());
            pst.setInt(10, clie.getIdCliente());
            pst.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro, Erro ao acessar o bando de dados: " + ex, "Alerta", 0);
        }
    }
    
    public ArrayList<Cliente> listaCliente(){
        String sql = "SELECT * FROM `dbo.cli_for` ORDER BY `Nome` ASC";
        try {
            pst = conexao.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                Cliente clie = new Cliente();
                clie.setIdCliente(rs.getInt(1));
                clie.setNomeCliente(rs.getString(2));
                clie.setNoFaClinete(rs.getString(3));
                clie.setEndeCliente(rs.getString(4));
                clie.setBairCliente(rs.getString(5));
                clie.setCidaCliente(rs.getString(6));
                clie.setEstaCliente(rs.getString(7));
                clie.setDocuCliente(rs.getString(9));
                clie.setFoneCliente(rs.getString(10));
                clientes.add(clie);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro, Erro ao acessar o bando de dados: " + ex, "Alerta", 0);
            return clientes;
        }
        return clientes;
    }
    
    public ResultSet listaClienteComLike(String nome){
        String sql = "SELECT * FROM `dbo.cli_for` WHERE `Nome` LIKE ?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, nome + "%");
            rs = pst.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro, Erro ao acessar o bando de dados: " + ex, "Alerta", 0);
            return null;
        }
        return rs;
    }
    
}
