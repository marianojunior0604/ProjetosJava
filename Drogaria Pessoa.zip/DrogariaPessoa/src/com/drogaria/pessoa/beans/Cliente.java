/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.drogaria.pessoa.beans;

/**
 *
 * @author Junior
 */
public class Cliente {
    
    private int idCliente;
    private String nomeCliente;
    private String noFaClinete;
    private String endeCliente;
    private String bairCliente;
    private String cidaCliente;
    private String estaCliente;
    private String docuCliente;
    private String daCaCliente;
    private String daAlCliente;
    private String foneCliente;

    public Cliente() {
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getNoFaClinete() {
        return noFaClinete;
    }

    public void setNoFaClinete(String noFaClinete) {
        this.noFaClinete = noFaClinete;
    }

    public String getEndeCliente() {
        return endeCliente;
    }

    public void setEndeCliente(String endeCliente) {
        this.endeCliente = endeCliente;
    }

    public String getBairCliente() {
        return bairCliente;
    }

    public void setBairCliente(String bairCliente) {
        this.bairCliente = bairCliente;
    }

    public String getCidaCliente() {
        return cidaCliente;
    }

    public void setCidaCliente(String cidaCliente) {
        this.cidaCliente = cidaCliente;
    }

    public String getEstaCliente() {
        return estaCliente;
    }

    public void setEstaCliente(String estaCliente) {
        this.estaCliente = estaCliente;
    }

    public String getDocuCliente() {
        return docuCliente;
    }

    public void setDocuCliente(String docuCliente) {
        this.docuCliente = docuCliente;
    }

    public String getDaCaCliente() {
        return daCaCliente;
    }

    public void setDaCaCliente(String daCaCliente) {
        this.daCaCliente = daCaCliente;
    }

    public String getDaAlCliente() {
        return daAlCliente;
    }

    public void setDaAlCliente(String daAlCliente) {
        this.daAlCliente = daAlCliente;
    }

    public String getFoneCliente() {
        return foneCliente;
    }

    public void setFoneCliente(String foneCliente) {
        this.foneCliente = foneCliente;
    }
}
